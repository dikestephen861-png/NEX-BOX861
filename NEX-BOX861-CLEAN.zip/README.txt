NEX BOX CLEAN DEPLOYMENT

Upload these files to the ROOT of the NEX-BOX861 repository:
- index.html
- admin.html
- manifest.json
- sw.js
- .github/workflows/deploy.yml

This version intentionally uses index.html for BOTH the movie catalogue and movie player.
Movie links are ./?movie=UUID, so there is no separate watch.html URL to produce a GitHub Pages 404.

Use only movies/video URLs you have permission to distribute.
